using System.Collections.Generic;

namespace ConsoleApplication1
{
    public class Measurement
    {
        IDictionary<string, int> Measurments = new Dictionary<string, int>();

        public void addMeasurment(string key, int value) {
            Measurments[key] = value;
        }
    }
}