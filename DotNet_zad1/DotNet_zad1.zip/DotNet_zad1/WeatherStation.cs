﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace ConsoleApplication1
{
    [DataContract]
    [KnownType(typeof(TemperatureSensor))]
    [KnownType(typeof(PressureSensor))]
    [KnownType(typeof(HumidityNTemperatureSensor))]
    class WeatherStation 
    {
        [DataMember(Name="Sensor")]
        private List<Sensor> sensors = new List<Sensor>();

        private List<Measurement> measurements;

        public WeatherStation()
        {

//            PressureSensor pSensor = new PressureSensor { pressure = 21 };
//            TemperatureSensor tSensor = new TemperatureSensor { degrees = "C", temperature = 30,Name="sensor Temp" };
//            HumidityNTemperatureSensor htSensor = new HumidityNTemperatureSensor {temperature = 22, degrees = "F", humidity = "good" };

//            sensors.Add(pSensor);
//            sensors.Add(tSensor);
//            sensors.Add(htSensor);
//            Console.WriteLine(tSensor.getTemperature());
            measurements  = new List<Measurement>();
            
        }
//
        public void addSensor(Sensor sensor)
        {
            sensor.sensorEvent += addMeasurment;
        }
        
        public void addMeasurment(Measurement measurement)
        {
            measurements.Add(measurement);
        }
//
//        public void getSenor(String value)
//        {
//            if (value.Equals("temperature"))
//            {
//                foreach (Sensor aSensor in sensors)
//                {
//                    if (aSensor is ITemperature)
//                    {
//                        Console.WriteLine("Sensor name: " + aSensor.Name);
//                    }
//                }
//            }else if (value.Equals("pressure"))
//            {
//                foreach (Sensor aSensor in sensors)
//                {
//                    if (aSensor is IPressure)
//                    {
//                        Console.WriteLine("Sensor name: " + aSensor.Name);
//                    }
//                }
//            }else if (value.Equals("humidity"))
//            {
//                foreach (Sensor aSensor in sensors)
//                {
//                    if (aSensor is IHumidity)
//                    {
//                        Console.WriteLine("Sensor name: " + aSensor.Name);
//                    }
//                }
//            }
//        }
//
//        public List<ITemperature> getSensorBySpecyficValue(int value)
//        {
//            return sensors.OfType<ITemperature>().Where(sensors => sensors.temperature > value).ToList();
//
//        }

    }
}